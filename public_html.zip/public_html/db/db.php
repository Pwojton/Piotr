<?php
function init_baza($dbfile) {
	global $db,$kom;
	try {
		if (!file_exists($dbfile)) $kom[]='Próba utworzenia nowej bazy...';
		$db=new PDO("sqlite:$dbfile");
		$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	} catch(PDOException $e) {
		echo ($e->getMessage());
	}
}

function db_exec($qstr) {
	global $db,$kom;
	$kom[]='Wykonuję: '.$qstr.'<br />';
	$ret=null;
	try {
		$ret=$db->exec($qstr);
	} catch(PDOException $e) {
		echo ($e->getMessage());
	}
	return $ret;
}

function db_lastInsertID() {
	global $db;
	return $db->lastInsertId();
}

function get_err() {
	global $db,$kom;
	foreach ($db->errorInfo() as $e)
		if ($e!='00000') $kom[]=$e;
}

function db_query($qstr,&$ret=null) {
	global $db,$mode,$mode;
	$kom[]='Wykonuję: '.$qstr.'<br />';
	$res=null;
	try {
		$res=$db->query($qstr);
	} catch(PDOException $e) {
		echo ($e->getMessage());
	}
	if ($res) $ret=$res->fetchAll($mode);
	if (empty($ret)) return false;
	return true;
	}

$initstr = "BEGIN;
CREATE TABLE users(
    u_id INTEGER PRIMARY KEY NOT NULL,
    u_login CHAR(20) UNIQUE NOT NULL,
    u_password CHAR(20) NOT NULL,
    u_email char(40) UNIQUE NOT NULL,
    data_dodania INT NOT NULL
);

REATE TABLE uczniowie (
		id INTEGER PRIMARY KEY NOT NULL AUTOINCREMENT,
		imie varchar(50),
		nazwisko varchar(50),
		plec BOOLEAN,
		id_klasa INTEGER(1) NOT NULL,
    FOREIGN KEY (id_klasa) REFERENCES klasy(id),
    ON DELETE CASCADE ON UPDATE NO ACTION
);

CREATE TABLE klasy (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		klasa text(2),
		rok_naboru INTEGER(4),
		rok_matury INTEGER(4)
);

INSERT INTO users VALUES (NULL, 'admin', '".sha1('admin')."', 'admin@home.pl', time());
COMMIT;
";

?>
