<?php
$pages = array(
    'witam' => 'Aplikacja w PHP',
    'formularz' => 'Formularz',
    'sqlcmd' => 'SQL'
); 
function get_menu($id) {
    global $pages;
    foreach ($pages as $klucze => $wartosc) {
        echo '
        <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="?id='.$klucz.'">'.$wartosc.'</a>
        </li>';
    }
}


?>
