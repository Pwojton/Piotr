<?php
// wyloguj.html
  global $user;
  $user->logout();
  $user->getKom();
 ?>
