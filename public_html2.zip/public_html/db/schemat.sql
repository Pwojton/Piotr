CREATE TABLE users(
    u_id INTEGER PRIMARY KEY NOT NULL,
    u_login CHAR(20) UNIQUE NOT NULL,
    u_password CHAR(20) NOT NULL,
    u_email char(40) UNIQUE NOT NULL,
    data_dodania INT NOT NULL
);

INSERT INTO users VALUES (NULL, 'admin','admin', 'admin@home.pl', time());
